export class CreateRoleDto {}
